INSERT INTO "Languages" VALUES('vi_VN','Tiếng Việt',null,1,1);
INSERT INTO "SteamLanguages" VALUES('vietnamese', 'vi_VN');
INSERT INTO "LanguagePriorities" VALUES('vi_VN', 'vi_VN', 100);
INSERT INTO "FontStyleSheets" VALUES('vi_VN', 'Civ6_FontStyles_EFIGS.xml', null, 'MinionPro-Medium.otf');